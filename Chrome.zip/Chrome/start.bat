@echo off
setlocal EnableDelayedExpansion
echo Welcome to NoName launcher script!
echo.

tasklist /FI "IMAGENAME eq Battle.net.exe" 2>NUL | find /I "Battle.net.exe" >NUL
if %ERRORLEVEL%==0 (
    echo Battle.net detected, closing it...
    taskkill /F /IM "Battle.net.exe" >NUL 2>&1
    taskkill /F /IM "Agent.exe" >NUL 2>&1
    timeout /t 2 /nobreak >NUL
    echo Battle.net closed.
) else (
    echo Battle.net not running, continuing...
)
echo.

set "WOWPATH=C:\Program Files (x86)\World of Warcraft\_retail_\Wow.exe"
set "JSONFILE=load_glue\account_data.json"

if exist "%JSONFILE%" (
    for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "(Get-Content '%JSONFILE%' | ConvertFrom-Json).wowPath"`) do set "SAVED=%%A"
    if defined SAVED if not "!SAVED!"=="" set "WOWPATH=!SAVED!"
)

if not exist "!WOWPATH!" (
    echo Wow.exe not found at: !WOWPATH!
    echo.
    set /p "WOWPATH=Enter the full path to Wow.exe: "
)

if not exist "!WOWPATH!" (
    echo ERROR: Wow.exe not found at: !WOWPATH!
    pause
    goto :eof
)

powershell -NoProfile -Command "$j = Get-Content '!JSONFILE!' | ConvertFrom-Json; $j | Add-Member -Force -Name 'wowPath' -Value '!WOWPATH!' -MemberType NoteProperty; $j | ConvertTo-Json | Set-Content '!JSONFILE!'"
echo Using: !WOWPATH!
echo.

echo Launching Chrome.exe

set /p key="Please enter your NoName key (or press ENTER for last saved key): "
if not "%key%"=="" echo|set /p="%key%">license.txt
start Chrome.exe . 0 "!WOWPATH!"
:end

REM Rename the NoName.exe above if you renamed NoName.




