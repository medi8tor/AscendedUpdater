-------------------------------------------
-- DO NOT CHANGE ANYTHING IN THIS FILE !!!!
-- Version 9
-- You can change the values in account_data.json
-------------------------------------------
if not QuitGame then return end

local NoName = ...
local json_decode = Utils.JSON.decode
local data = {}
local raw = ReadFile("/load_glue/account_data.json")
local accounts = json_decode(raw)

local data = {}

local function logger(info)
	local dateTime = date()
	local txt = dateTime .. " " .. info.."\n"
	if data.logging and data.logging == true then
		if not FileExists("/load_glue/relogger_log.log") then
			WriteFile("/load_glue/relogger_log.log",txt,false)
		else
			WriteFile("/load_glue/relogger_log.log",txt,true)
		end
	end
end

-- compatibility for array of details
if accounts.enabled == nil then
	local accountIndex = (NoName.GetSessionIndex() % #accounts)+1
	data = accounts[accountIndex] -- multiple
	logger("AccountLogin UI - selecting account with index " .. tostring(accountIndex) .. " " .. tostring(NoName.GetSessionIndex()))
else
	data = accounts -- old, single acc used
	logger("AccountLogin UI - selecting account")
end

data.realmname = data.realmName
data.playerslot = data.playerSlot
data.waitbeforeentering = data.waitBeforeEntering
data.maxattempts = data.maxAttempts

local isBlocked = false
local attempts = 0
local function resetAttempts()
	attempts = 0
	isBlocked = false
	logger("AccountLogin UI - resetting attempts now")
end

if data.enabled then

    C_Timer.After(3, function()
        local timer
        timer = C_Timer.NewTicker(4, function()
			if attempts >= data.maxAttempts then
				logger("AccountLogin UI - blocked because of too many attempts")
				if not isBlocked then
					isBlocked = true
					logger("AccountLogin UI - schedule reset attempts in 900 seconds")
					C_Timer.After(900,resetAttempts)
				end
				return
			end
            local mystate, _, _, hrl, wfrl = C_Login.GetState()
            if mystate == LE_AURORA_STATE_NONE and not wfrl and not hrl and
                GlueDialog:IsShown() then
                GlueDialog_Hide()
            end
            if GlueDialog:IsShown() then
				logger("AccountLogin UI - blocked because glue dialogs")
                return
            end
            if (AccountLogin and AccountLogin.UI.WoWAccountSelectDialog:IsShown()) then
				logger("AccountLogin UI - AccountLogin")
				local realAccount = data.account
				local maxIter = MAX_ACCOUNTNAME_DISPLAYED or 12
				for i=1, maxIter do
					local accName = AccountLogin.UI.WoWAccountSelectDialog.gameAccounts[i]
					if accName and string.upper(accName) == string.upper(data.account) then
						realAccount = accName
						break
					end
				end
                C_Login.SelectGameAccount(realAccount)
				if realAccount then
					logger("AccountLogin UI - selecting game account: "..realAccount)
				else
					logger("AccountLogin UI - selecting game account: unknown")
				end
            elseif (AccountLogin and AccountLogin.UI:IsVisible()) then
				attempts = attempts+1
				logger("AccountLogin UI - logging in now")
				local reconnectButton = AccountLogin.UI.ReconnectLoginButton;
				if reconnectButton:IsShown() and reconnectButton:IsEnabled() and C_Login.IsLoginReady() then
					UpdateLastHardwareAction()
					Unlock(AccountLogin_ReconnectLogin)
				else
					AccountLogin.UI.AccountEditBox:SetText(data.username)
					AccountLogin.UI.PasswordEditBox:SetText(data.password)
					UpdateLastHardwareAction()
					AccountLogin_Login()
				end
			elseif (RealmListUI and RealmListUI:IsVisible()) then
				logger("AccountLogin UI - RealmListUI")
                local roptions = C_RealmList.GetAvailableCategories()
                for i = 1, #roptions do
                    local allrealms = C_RealmList.GetRealmsInCategory(roptions[i])
                    for j = 1, #allrealms do
                        local realmaddress = allrealms[j]
                        local realmname, _ = C_RealmList.GetRealmInfo(realmaddress)
						if type(realmname) == "table" then
							realmname = realmname.name -- TWW change
						end
                        if realmname == data.realmname then
                            RealmList.selectedRealm = realmaddress
							logger("AccountLogin UI - selecting realm: " .. realmname)
                            RealmList_Update()
                            RealmList_OnOk()
                        end
                    end
                end
            elseif (CharacterSelect and CharacterSelect:IsVisible()) then
				logger("AccountLogin UI - CharacterSelect")
				if GetServerName() ~= data.realmname and (not RealmList or not RealmList:IsVisible()) then
					if CharacterSelect_ChangeRealm then
						CharacterSelect_ChangeRealm()
					else
						CharacterSelectUtil.ChangeRealm()
					end
					logger("AccountLogin UI - change realm")
				else
					local randomizer = math.random(1,5)
					local timeToWait = data.waitBeforeEntering+randomizer
					if not timeToEnter then
						timeToEnter = GetTime()+timeToWait
					elseif timeToEnter and timeToEnter < GetTime() then
						if CharacterSelect_AllowedToEnterWorld() then
							timeToEnter = nil
							logger("AccountLogin UI - entering world on slot: "..data.playerslot .." with username: " .. data.username .. " on realm: " .. data.realmname)
							CharacterSelect_SelectCharacter(data.playerslot)
							UpdateLastHardwareAction()
							CharacterSelect_EnterWorld()
						end
					end
				end
			end
        end)
    end)
end
